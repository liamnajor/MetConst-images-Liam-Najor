var c = []
var button = function(){
    var bytes = document.getElementById("Bytes").value
    var e = bytes.length
    while(e >= 0){
        var counter = e/2 -1
        var b = e - 2
        var res = bytes.substr(b, e)
        c[counter] = res.substr(0, 2)
        e = b
    }
    document.getElementById("output HEX").value = c
    document.getElementById("items").value = c[20089]
    document.getElementById("beams").value = c[20090]
    document.getElementById("etanks").value = c[20091]
    document.getElementById("chealth").value = c[20092]
    document.getElementById("cetanks").value = c[20093]
    document.getElementById("missilec").value = ""+c[20095]+""+c[20094]+""
    document.getElementById("missiles").value = ""+c[20097]+""+c[20096]+""
}
var encode = function(){
    var value = ""
    c[20089] = document.getElementById("items").value
    c[20090] = document.getElementById("beams").value
    c[20091] = document.getElementById("etanks").value
    c[20092] = document.getElementById("chealth").value
    c[20093] = document.getElementById("cetanks").value
    c[20094] = document.getElementById("missilec").value.substr(2, 4)
    c[20095] = document.getElementById("missilec").value.substr(0, 2)
    c[20096] = document.getElementById("missiles").value.substr(2, 4)
    c[20097] = document.getElementById("missiles").value.substr(0, 2)
    document.getElementById("output HEX").value = c
    var i = 0
    while(i <= c.length){
        value += c[i]
        i += 1
    }
    document.getElementById("Bytes").value = value
    update(value)
    window.alert("encoding complete")
}
var canvas = document.getElementById("Tiles");
var ctx = canvas.getContext("2d");
ctx.fillStyle = "black";
ctx.fillRect(0, 0, canvas.width, canvas.height);   
var canvas = document.getElementById("Sprites");
var ctx = canvas.getContext("2d");
ctx.fillStyle = "black";
ctx.fillRect(0, 0, canvas.width, canvas.height);   
var canvas = document.getElementById("Colors");
var ctx = canvas.getContext("2d");
ctx.fillStyle = "black";
ctx.fillRect(0, 0, canvas.width, canvas.height);